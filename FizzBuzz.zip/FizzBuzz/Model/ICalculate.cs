﻿namespace FizzBuzz.Model
{
    public interface ICalculate
    {
        int GetMultiple(int Id);
    }
}
