﻿using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata;

namespace FizzBuzz.Model
{
    public class Calculate //: ICalculate
    {
        //private readonly ICalculate _service;
        //public Calculate(ICalculate service)
        //{
        //    _service = service;
        //}
        public void GetMultiple(int Id)
        {
            int x=Id;
            //int x = Convert.ToInt32(Console.ReadLine());

            if (x > 0)
            {

                if (x % 3 != 0 || x % 5 != 0)
                {
                    Console.WriteLine("Divided " + x + " by 3");
                    Console.WriteLine("Divided " + x + " by 5");
                }
                else if (x == 3)
                {
                    Console.WriteLine("Fizz");
                }

                else if (x == 5)
                {
                    Console.WriteLine("Buzz");
                }

                else if (x == 15)
                {
                    Console.WriteLine("FizzBuzz");
                }

                //Console.WriteLine(x % 3 == 0 || x % 7 == 0);
            }
            else
            {
                Console.WriteLine("Invalid Item");
            }
            //return Id;
        }

    }
}
