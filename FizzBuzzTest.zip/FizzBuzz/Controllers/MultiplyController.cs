﻿using FizzBuzz.Model;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata;

namespace FizzBuzz.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MultiplyController
    {
        private readonly Calculate _service;
        public MultiplyController(Calculate service) 
        { 
           _service = service;
        }
        

        [HttpGet("{Id}")]
        public string Multiply1(string Id)
        {
            string Y = Id;
            //int x = Convert.ToInt32(Console.ReadLine());
            if (string.IsNullOrEmpty(Y) || Y == "A")
            {
                return "Invalid Item";
            }
            
            int x = Convert.ToInt32(Id);

            if (x > 0)
            {
                
                if (x == 3)
                {
                    string s = "Fizz";
                    return s;
                }

                else if (x == 5)
                {
                    string s = "Buzz";
                    return s;
                }

                else if (x == 15)
                {
                    string s = "FizzBuzz";
                    return s;
                }

                else if(x % 3 != 0 || x % 5 != 0)
                {
                    string s = "Divided " + x + " by 3";
                    string t = "Divided " + x + " by 5";
                    return s + t;
                }
            }
            else
            {
                string s = "Invalid Item";
                //Console.WriteLine("Invalid Item");
                //System.Diagnostics.Debug.WriteLine("Invalid Item");
                return s;
            }
            return "Please check output";
        }
    }
}
