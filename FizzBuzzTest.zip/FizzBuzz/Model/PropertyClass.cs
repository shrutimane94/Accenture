﻿namespace FizzBuzz.Model
{
    public class PropertyClass
    {
        public int Id { get; set; }
    }
}
