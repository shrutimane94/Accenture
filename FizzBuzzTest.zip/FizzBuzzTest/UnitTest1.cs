﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FizzBuzz.Controllers;
using System;
using System.IO;

namespace FizzBuzzTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestNumber3()
        {
            string Expected = "Fizz";
            var result = MultiplyController();
            Assert.AreEqual(Expected, result);
            
        }

        public void TestNumber5()
        {
            string Expected = "Buzz";
            var result = MultiplyController();
            Assert.AreEqual(Expected, result);

        }

        public void TestNumber15()
        {
            string Expected = "FizzBuzz";
            var result = MultiplyController();
            Assert.AreEqual(Expected, result);

        }

        public void TestNumber1()
        {
            string Expected = "Divided 1 by 3"+ "Divided 1 by 5";
            var result = MultiplyController();
            Assert.AreEqual(Expected, result);

        }

        public void TestNumber23()
        {
            string Expected = "Divided 23 by 3" + "Divided 23 by 5";
            var result = MultiplyController();
            Assert.AreEqual(Expected, result);

        }
        public void TestEmpty()
        {
            string Expected = "Invalid item";
            var result = MultiplyController();
            Assert.AreEqual(Expected, result);

        }
        public void TestChar()
        {
            string Expected = "Invalid item";
            var result = MultiplyController();
            Assert.AreEqual(Expected, result);

        }
    }
}
